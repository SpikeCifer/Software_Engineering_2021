Eclipse is aware of 2 User Libraries: ApachePoi and FreeTTS
For the sake of keeping the size of the project small (as well as github's limitation of files uploaded),
we have not included the lib files in the turnin folder.

Installation Guide:
Kindly add the 2 folders containing the libraries to their appointed container-folders
As in:
1. A folder (We were using the poi-5.0.0) containing the apache API goes in ApachePoi folder and
2. A folder (We were using the freetts-1.2) containg the Transformation API goes in FreeTTS folder
