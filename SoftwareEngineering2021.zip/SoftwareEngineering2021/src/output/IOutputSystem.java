package output;

import java.util.ArrayList;

public interface IOutputSystem {
	public void write(ArrayList<String> contents);
}
