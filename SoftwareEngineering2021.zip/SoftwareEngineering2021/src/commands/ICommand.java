package commands;

public interface ICommand {
	public void execute();
}
