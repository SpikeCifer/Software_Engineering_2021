package input;

import java.util.ArrayList;

public interface IDecodeStrategy {
	public ArrayList<String> decode(ArrayList<String> fileContents);
}
