package input;

import java.util.ArrayList;

public interface IInputSystem {	
	public ArrayList<String> read(); 
}
