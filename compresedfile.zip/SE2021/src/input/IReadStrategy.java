package input;

import java.util.ArrayList;

public interface IReadStrategy {
	public ArrayList<String> read(String filename);
}
