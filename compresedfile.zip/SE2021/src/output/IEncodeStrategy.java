package output;

import java.util.ArrayList;

public interface IEncodeStrategy {
	public ArrayList<String> encode(ArrayList<String> contents);
}
